-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-01-2023 a las 00:34:04
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `baloncestoliga`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `baloncestistas`
--

CREATE TABLE `baloncestistas` (
  `id_baloncestistas` int(255) NOT NULL,
  `nombre_baloncestistas` varchar(255) DEFAULT NULL,
  `apellido_baloncestistas` varchar(255) DEFAULT NULL,
  `nacionalidad_baloncestistas` varchar(255) DEFAULT NULL,
  `valoracionDraft_baloncestistas` int(255) DEFAULT NULL,
  `pertenece_franquicia` int(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `baloncestistas`
--

INSERT INTO `baloncestistas` (`id_baloncestistas`, `nombre_baloncestistas`, `apellido_baloncestistas`, `nacionalidad_baloncestistas`, `valoracionDraft_baloncestistas`, `pertenece_franquicia`) VALUES
(4, 'Sergio', 'Llull', 'España', 10, 13),
(1, 'Walter ', 'Tavares', 'Cabo Verde', 8, 13),
(3, 'Dzanan', 'Musa', 'Bosnia', 6, 13),
(5, 'Nikola', 'Mirotic', 'Montenegro', 10, 14),
(6, 'Oscar', 'da Silva', 'Alemania', 5, 14),
(7, 'Nicolas', 'Laprovittola', 'Argentina', 6, 14),
(8, 'Jimmy', 'Butler', 'Estados Unidos', 7, 15),
(9, 'Tyler', 'Herro', 'Estados Unidos', 6, 15),
(10, 'Nikola', 'Jovic', 'Reino Unido', 5, 15),
(11, 'Paolo', 'Banchero', 'Estados Unidos', 9, 16),
(12, 'Franz', 'Wagner', 'Alemania', 6, 16),
(13, 'Jalen', 'Suggs', 'Estados Unidos', 8, 16),
(14, 'Ja', 'Morant', 'Estados Unidos', 8, 17),
(15, 'Desmond', 'Bane', 'Estados Unidos', 9, 17),
(16, 'Dillon', 'Brooks', 'Canada', 8, 17),
(17, 'Jamal', 'Murray', 'Canada', 9, 18),
(18, 'Michael', 'Porter Jr.', 'Estados Unidos', 6, 18),
(19, 'Christian', 'Braun', 'Estados Unidos', 8, 18),
(2, 'Sergio', 'Rodriguez', 'España', 10, 13),
(20, 'Mario', 'Hezonja', 'Croacia', 7, 13),
(21, 'Cory', 'Higgins', 'Estados Unidos', 7, 14),
(22, 'Jan', 'Vesely ', 'Republica Checa', 7, 14),
(23, 'Kyle', 'Lowry', 'Estados Unidos', 9, 15),
(24, 'Bam', 'Adebayo', 'Estados Unidos', 9, 15),
(25, 'Bol', 'Bol', 'Sudan', 8, 16),
(26, 'Cole', 'Anthony', 'Estados Unidos', 7, 16),
(27, 'Danny', 'Green', 'Estados Unidos', 6, 17),
(28, 'Steven', 'Adams', 'Nueva Zelanda', 9, 17),
(29, 'Nikola', 'Jokic ', 'Serbia', 9, 18),
(30, 'Kentavious', 'Caldwell-Pope', 'Estados Unidos', 7, 18);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conferencias`
--

CREATE TABLE `conferencias` (
  `nombre` varchar(255) NOT NULL,
  `pais` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `conferencias`
--

INSERT INTO `conferencias` (`nombre`, `pais`) VALUES
('Liga ACB', 'España'),
('NBA este', 'Estados Unidos'),
('NBA oeste', 'Estados Unidos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `franquicia`
--

CREATE TABLE `franquicia` (
  `id_franquicia` int(255) NOT NULL,
  `nombre_franquicia` varchar(255) DEFAULT NULL,
  `nombre_entrenador` varchar(255) DEFAULT NULL,
  `estadio_franquicia` varchar(255) DEFAULT NULL,
  `nombre_confenrecia` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `franquicia`
--

INSERT INTO `franquicia` (`id_franquicia`, `nombre_franquicia`, `nombre_entrenador`, `estadio_franquicia`, `nombre_confenrecia`) VALUES
(13, 'Real Madrid Baloncesto', 'Chus Mateo', 'WiZink Center de Madrid', 'Liga ACB'),
(14, 'FC Barcelona Baloncesto', 'Sarunas Jasikevicius', 'Palau Blaugrana', 'Liga ACB'),
(15, 'Miami Heat', 'Erik Spoelstra', 'FTX Arena', 'NBA este'),
(16, 'Orlando Magic', 'Jamahl Mosley', 'Amway Center', 'NBA este'),
(17, 'Memphis Grizzlies', 'Taylor Jenkins', 'FedExForum', 'NBA oeste'),
(18, 'Denver Nuggets', 'Michael Malone', ' Ball Arena', 'NBA oeste');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `partidos`
--

CREATE TABLE `partidos` (
  `id_partido` int(255) NOT NULL,
  `id_franquicialocal` int(255) DEFAULT NULL,
  `id_franquiciavisitante` int(255) DEFAULT NULL,
  `asistencia` int(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `partidos`
--

INSERT INTO `partidos` (`id_partido`, `id_franquicialocal`, `id_franquiciavisitante`, `asistencia`) VALUES
(6, 13, 14, 45926),
(7, 15, 16, 74249),
(8, 17, 18, 40240),
(9, 14, 13, 98394),
(10, 16, 15, 20000),
(11, 18, 17, 23500);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `baloncestistas`
--
ALTER TABLE `baloncestistas`
  ADD PRIMARY KEY (`id_baloncestistas`),
  ADD KEY `FK_baloncestistas` (`pertenece_franquicia`);

--
-- Indices de la tabla `conferencias`
--
ALTER TABLE `conferencias`
  ADD PRIMARY KEY (`nombre`);

--
-- Indices de la tabla `franquicia`
--
ALTER TABLE `franquicia`
  ADD PRIMARY KEY (`id_franquicia`),
  ADD KEY `FK_franquicia` (`nombre_confenrecia`);

--
-- Indices de la tabla `partidos`
--
ALTER TABLE `partidos`
  ADD PRIMARY KEY (`id_partido`),
  ADD KEY `FK_partidos` (`id_franquicialocal`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `baloncestistas`
--
ALTER TABLE `baloncestistas`
  MODIFY `id_baloncestistas` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `franquicia`
--
ALTER TABLE `franquicia`
  MODIFY `id_franquicia` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `partidos`
--
ALTER TABLE `partidos`
  MODIFY `id_partido` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
